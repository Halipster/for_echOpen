from arduino import toArduino, toBytes, toSignal
import numpy as np
import scipy.signal as sp
import matplotlib.pyplot as plt

delay = 11;

N = 11520

Fs = 40e6
dt = 1/Fs
t = np.arange(N)*dt
t_end = 5e-6
N_end = int(t_end*Fs)
s = np.array(np.sin(t)*128,dtype='int8')

chirp = sp.chirp(t, 1e6, t_end, 5e6, phi=-90)*np.pad(np.hanning(N_end),(0, int(N-N_end)), 'constant') 
chirp = np.int8(np.round(chirp*86))

s = toSignal(toArduino(toBytes(chirp)))

a = np.convolve(1.0*chirp,1.0*aFilter,'same')
b = np.convolve(1.0*chirp,1.0*aFilter[::-1],'same')
s_th = (a**2 + b**2)/2**14

plt.plot(chirp[:N_end],'--',label='signal')       
plt.plot(np.sqrt(s_th[:N_end]),'--',label='theorical')
plt.plot(np.sqrt(s[delay:N_end+delay]*2.0**6),label='FPGA')
plt.legend()
plt.xlabel('samples')
plt.title('fpga enveloppe detection')
plt.show()