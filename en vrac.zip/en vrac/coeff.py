import numpy as np
import matplotlib.pyplot as plt 

n = 32         # FIR number of taps
    
# construct ideal hilbert filter truncated to desired length
fc = 1;
tc = fc/2 * np.arange((1-n)/2,(n+1)/2);
hfilt = np.sinc(tc)*np.exp(1j*np.pi*tc);

# multiply ideal filter with tapered window
beta = 6;
firFilter = hfilt*np.kaiser(n,beta);
firFilter /= np.sum(np.real(firFilter));
                   
# apply rotation
firFilter *= np.exp(1j*np.pi/4)

# to 8-bit

aFilter = np.real(firFilter)
aFilter *= 2**9
aFilter = np.int16(aFilter)

# plot
plt.figure(1)
plt.plot(aFilter)
plt.show()

plt.figure(2)
gIdeal = np.abs(np.fft.fftshift(np.fft.fft(np.hstack([np.real(firFilter), [0]*(1024-n)]))))
g = np.abs(np.fft.fftshift(np.fft.fft(np.hstack([aFilter, [0]*(1024-n)]))))
f = np.arange(-512,512)/512
plt.plot(f,gIdeal,'--')
plt.plot(f,g)
plt.show()

aFilter
coeff = aFilter

for i in range (len(coeff)): 
    print('10\'b'+format(coeff[i] if coeff[i] >= 0 else (1 << 10) + coeff[i], '010b')+',',end='')
