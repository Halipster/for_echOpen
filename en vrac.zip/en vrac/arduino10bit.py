# -*- coding: utf-8 -*-
'''
Serial Arduino Communication Test - The Arduino is set in a echo mode with a 
determined buffer size. We send data and then receive it. If the buffer is 
smaller than the sent data it will response back before the end of 
transmission. This is not a problem as long as the computer serial buffer is 
not saturated.
'''

import time
import serial
import numpy as np

BAUD_RATE = 115200                  # Must be the same as the arduino
BITS_PER_BYTE = 10                  # Depend on serial chosen protocol. By 
                                    # default it is 1 Byte = 10 bits (8 bits
                                    # of data plus one starting and one ending
                                    # bit)  

def toArduino(dataIN, baudrate=BAUD_RATE):
    N = len(dataIN)
    dataOUT = b''   # Varaible for storing the received data
    with serial.Serial(port='COM10', baudrate=baudrate) as ser: # Start serial
        if ser.isOpen():
            time.sleep(1)                   # Wait the en of initialisation
            ser.read(ser.inWaiting())       # Flush the eventual received bytes
            for i in range(N):
                ser.write(dataIN[i:i+1])    # Send Data
            for i in range(N):
                dataOUT += ser.read()       # Received Data
    return dataOUT


def test(baudrate=BAUD_RATE):
    # To perform data integrity, set the device in an echo mode
    N = int(BAUD_RATE/BITS_PER_BYTE)   # Transmision size. Here we choose it  
                                       # in order to have an ideal transmission 
                                       # plus reception of 2 seconds  
                                      
      #din = np.random.randint(-512,512,int(N/2),dtype='int16')
    din = np.array(np.random.randint(-512,512,int(N/2)))
# Random input data for transmission   

    t0 = time.time()
    dout = toSignal(toArduino(toBytes(din), baudrate))
    
    t = time.time() - 1              
    print('Theorical max speed :',round(BAUD_RATE/BITS_PER_BYTE), 'Bytes/s')
    print('Speed :', round(2*N/(t-t0)), 'Bytes/s')      # Control speed
    print('Data integrity :', np.all(din == dout))        # Control errors 
    return din, dout
    
def toBytes(s): 
    return np.array(np.round(s),dtype='>i2').tobytes()   

def toSignal(b): 
    s = np.frombuffer(b,dtype='>i2') % 1024
    s[s>=512] = s[s>=512] - 1024
    return np.array(s,dtype='int')
                     


    
    
    




