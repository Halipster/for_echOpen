from arduino10bit import toArduino, toBytes, toSignal
import numpy as np
import scipy.signal as sp
import matplotlib.pyplot as plt

delay = 0;

N = 11520/2

Fs = 40e6
dt = 1/Fs
t = np.arange(N)*dt
t_end = 5e-6
N_end = int(t_end*Fs)


chirp = sp.chirp(t, 1e6, t_end, 5e6, phi=-90)*np.pad(np.hanning(N_end),(0, int(N-N_end)), 'constant') 
chirp = np.round(chirp*512)

s = toSignal(toArduino(toBytes(chirp)))

plt.plot(chirp[:N_end],'--',label='signal')       
plt.plot(s[delay:N_end+delay],label='FPGA')
plt.legend()
plt.xlabel('samples')
plt.title('fpga enveloppe detection')
plt.show()